namespace CodeChum
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
            
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            Dictionary<string, string> users = new Dictionary<string, string>()
    {
        {"admin", "admin12345" },
        {"user1", "password123" },
        {"student1", "PF101@2024" }
    };

            bool isValidLogin = false;
            foreach (KeyValuePair<string, string> pair in users)
            {
                if (pair.Key == username && pair.Value == password)
                {
                    isValidLogin = true;
                    break;
                }
            }

            // Display appropriate message based on login validity
            if (isValidLogin)
            {
                resultLabel.Text = "Login Successful";
            }
            else
            {
                resultLabel.Text = "Invalid username or password.";
            }
        }
        private void resultlabel_Click(object sender, EventArgs e)
        {

        }
    }
}